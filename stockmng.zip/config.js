const mysql = require('mysql');
const normalizeUrl = url => {
    if (!(url.startsWith("http://") || url.startsWith("https://"))) {
        url = "http://" + url;
    }
    if (url.endsWith("/")) {
        url = url.substr(0, url.length - 1);
    }
    return url;
};

const BALANCEMNG_URL = normalizeUrl(process.env.BALANCEMNG_URL || "http://127.0.0.1:8080");
const getDomain = (url) => {
    let indexOfColonSlash = url.indexOf("://");
    if (indexOfColonSlash >= 0) {
        url = url.substr(indexOfColonSlash + 3);
    }

    let indexOfColon = url.indexOf(":");
    if (indexOfColon >= 0) {
        url = url.substr(0, indexOfColon);
    }

    let indexOfSlash = url.indexOf("/");
    if (indexOfSlash >= 0) {
        url = url.substr(0, indexOfSlash);
    }

    return url;
};

const databasePool = mysql.createPool({
    host: process.env.DB_HOST || "rm-p2u21oov2y6xf35533o.mysql.rds.aliyuncs.com",
    user: process.env.DB_USER || "root",
    password: process.env.DB_PASSWORD || "Ali_1234",
    database: process.env.DB_DATABASE || "stockmng_serverless",
});

const getConnection = () => {
    return new Promise((resolve, reject) => {
        databasePool.getConnection((err, connection) => {
            if (err) {
                reject(err);
            } else {
                resolve(connection);
            }
        });
    });
};

module.exports = {BALANCEMNG_URL, getConnection, getDomain};