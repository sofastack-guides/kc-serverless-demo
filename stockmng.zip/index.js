const fs = require("fs");
const express = require('express');
const bodyParser = require('body-parser');
const config = require("./config");

const controller = require('./controller');
const app = express();
const port = 3000;

app.use(express.static('public'));
app.use(bodyParser.json());

fs.writeFileSync("/etc/hosts", `\n139.224.240.157 ${config.getDomain(config.BALANCEMNG_URL)}\n`, {flag: "a"});

const register = (path, callback) => {
    app.all(path, async (req, res) => {
        try {
            return await callback(req, res);
        } catch (e) {
            res.status(500);
            res.send({err: e.message});
        }
    });
};

register('/query', controller.query);
register('/purchase', controller.purchase);
register('/createUser', controller.createUser);
register('/queryBalance', controller.queryBalance);

app.listen(port, () => console.log(`stockmng listening on port ${port}`));