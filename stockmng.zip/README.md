stockmng
---

NodeJS版本stockmng后端，Serverless产品演示用。
监听端口：3000。

## 链接汇总
* [DEMO前端](http://gitlab.alipay-inc.com/zhongle.wk/kubecon-demo)
* [SOFABoot微服务版后端](https://github.com/sofastack-guides/kc-sofastack-demo/)
* Serverless微服务版: [balancemng](http://gitlab.alipay-inc.com/zhongle.wk/balancemng) + [stockmng](http://gitlab.alipay-inc.com/zhongle.wk/stockmng)
* [二合一版Java后端](http://gitlab.alipay-inc.com/zhongle.wk/kubecon-demo-java-backend)

## 配置
`./config.js`

需要配置环境变量`BALANCEMNG_URL`指向[balancemng](http://gitlab.alipay-inc.com/zhongle.wk/balancemng)

## 运行
```
npm i
node index.js
```