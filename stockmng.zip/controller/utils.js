const axios = require("axios");
const config = require("../config");

function forwardResponse(res, response) {
    res.status(response.status);
    res.send(response.data);
}

let self = {
    makeBalanceMngCall: async (path, body) => {
        let url = config.BALANCEMNG_URL + "/" + path;
        return await axios.post(url, body);
    },
    proxyToBalanceMng: (path) => {
        return async (req, res) => {
            try {
                let url = config.BALANCEMNG_URL + "/" + path;
                if (req.originalUrl.indexOf("?") >= 0) {
                    url += req.originalUrl.substr(req.originalUrl.indexOf("?"));
                }
                forwardResponse(res, await axios({url, method: req.method, data: req.body}));
            } catch (e) {
                if (e.response) {
                    forwardResponse(res, e.response);
                } else {
                    res.status(500);
                    res.send(e.message);
                }
            }
        }
    },
    getInput: (request, key) => {
        return request.query[key] || request.body[key];
    },
    assert: (callback, errMsg) => {
        if (!callback()) {
            throw new Error(errMsg);
        }
    },
    assertNonEmpty: (req, fieldNames) => {
        for (let fieldName of fieldNames) {
            self.assert(() => !!self.getInput(req, fieldName), `${fieldName} cannot be empty`)
        }
    }
};

module.exports = self;