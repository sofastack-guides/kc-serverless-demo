const utils = require("./utils");
const config = require("../config");

function queryProductPrice(productCode) {
    return new Promise((resolve, reject) => {
        config.getConnection().then(connection => {
            connection.query("select price from stock_tb where product_code=?", [productCode], (error, results, fields) => {
                connection.release();
                if (!results || !results.length) {
                    reject(new Error("invalid productCode " + productCode));
                }
                resolve(results[0].price);
            });
        });
    });
}

module.exports = {
    query: async (req, res) => {
        utils.assertNonEmpty(req, ['userName']);

        const userName = utils.getInput(req, 'userName');
        const sql = "select id, stock_tb.product_code as productCode, name, description, price, sum(count) as ownedCount "
            + "from stock_tb "
            + "left outer join (select product_code, count from order_tb where user_name = ?) as user_orders "
            + "on stock_tb.product_code = user_orders.product_code "
            + "group by stock_tb.product_code;";

        let connection = await config.getConnection();

        connection.query(sql, [userName], (error, results, fields) => {
            connection.release();
            res.send(results);
        });
    },

    purchase: async (req, res) => {

        // validation
        utils.assertNonEmpty(req, ['userName', 'productCode', 'count']);

        const count = +utils.getInput(req, "count");
        const userName = utils.getInput(req, "userName");
        const productCode = utils.getInput(req, "productCode");
        utils.assert(() => !isNaN(count) && count > 0 && Math.floor(count) === count, 'invalid count');


        // calc total cost
        const productPrice = await queryProductPrice(productCode);
        const totalCost = productPrice * count;

        // minus balance
        await utils.makeBalanceMngCall('minusBalance', {userName, amount: totalCost});

        let connection = await config.getConnection();
        connection.query("insert into order_tb (user_name, product_code, count) values (?,?,?);", [userName, productCode, count], (error, results, fields) => {
            connection.release();
            res.send({success: true});
        });
    },
    createUser: utils.proxyToBalanceMng("createUser"),
    queryBalance: utils.proxyToBalanceMng("queryBalance"),
};